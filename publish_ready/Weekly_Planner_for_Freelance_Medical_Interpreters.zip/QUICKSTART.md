# Quick Start — Weekly Planner for Freelance Medical Interpreters

Get set up in under 10 minutes.

## Option A: Notion

1. Duplicate the template file into your Notion workspace.
2. Fill the Client/facility database with your first 3 facilities.
3. Block next week's appointments in the appointment grid, noting each facility's time zone.
4. Add your certification expiry dates to the tracker.

## Option B: Markdown / print

1. Open the template in any Markdown editor (or print it).
2. Copy the weekly grid per week; keep one running invoice table.

## Weekly routine (15 minutes every Sunday)

- Confirm assignments and time zones.
- Review terminology for the week's specialties.
- Update hours, invoice sent items, and CE progress.
