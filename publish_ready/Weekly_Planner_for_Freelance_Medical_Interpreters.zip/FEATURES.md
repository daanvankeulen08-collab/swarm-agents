# Features — Weekly Planner for Freelance Medical Interpreters

- Weekly appointment grid with time zone support — day/time slots, facility, department, room and a time zone column
- Client/facility database — facility name, address, contact, specialty, billing reference and a standing-notes field
- Medical terminology quick-reference by specialty — bilingual term pairs grouped by specialty with a plain-language meaning
- Invoice/hours tracking per assignment — date, facility, hours, rate, amount, payment status and a running total
- Certification deadline tracker — credential, CEU requirement, progress, expiry date and next renewal action
- Assignment protocol notes — pre-assignment confirmation, site arrival or remote-login checklist, privacy rules, encounter boundaries and escalation procedure

Plus: usage instructions, no special software required, lifetime updates of the template structure.
