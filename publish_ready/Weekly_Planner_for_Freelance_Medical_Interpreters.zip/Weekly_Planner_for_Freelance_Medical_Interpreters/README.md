# Weekly Planner for Freelance Medical Interpreters

Weekly Planner for Freelance Medical Interpreters — a ready-to-use digital product.

## Features

- Complete and ready to use — no modifications required
- Tested before packaging
- Includes usage examples

## Installation

No installation needed. Duplicate the `.md` template file and fill in your own content.

## Usage

1. Open the template file in any Markdown editor (Notion, Obsidian, VS Code).
2. See `examples/example_filled.md` for a filled-in example.

## Requirements

- Any Markdown editor
