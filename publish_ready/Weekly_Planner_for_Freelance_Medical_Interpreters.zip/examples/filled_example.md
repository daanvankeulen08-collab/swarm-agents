# Filled Example — a week with Maria R., freelance interpreter (Spanish/English)

## Weekly appointment grid (time zones noted)

| Day | Time | Facility | Specialty | Time zone |
|-----|------|----------|-----------|-----------|
| Mon | 09:00 | St. Mary Hospital | Cardiology | ET |
| Tue | 14:00 | Riverside Clinic | Neurology | CT |
| Thu | 10:30 | St. Mary Hospital | Pediatrics | ET |

## Client/facility database

- St. Mary Hospital — contact: J. Alvarez, scheduling — specialty: cardiology — terminology: catheter, stent, arrhythmia.
- Riverside Clinic — contact: T. Nguyen, office manager — specialty: neurology — terminology: seizure, MRI, neuropathy.

## Terminology quick-reference

- Cardiology: myocardial infarction = heart attack; tachycardia = fast heart rate.
- Neurology: cerebrovascular accident = stroke; paresthesia = tingling/numbness.

## Invoice/hours tracking

| Date | Facility | Hours | Rate | Amount | Paid |
|------|----------|-------|------|--------|------|
| Mon | St. Mary | 3 | $45 | $135 | yes |
| Tue | Riverside | 2 | $50 | $100 | no |

## Certification deadline tracker

- State court certification — CE 12/20 hours — expires Dec 2026 — next: medical ethics webinar.

## Assignment protocol notes

- St. Mary: check in at interpreter office, badge required, no phones in wards.
